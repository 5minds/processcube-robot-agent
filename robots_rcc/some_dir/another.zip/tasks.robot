*** Settings ***
Documentation   Template robot main suite.


*** Tasks ***
Another Minimal task
    Log  Done.
